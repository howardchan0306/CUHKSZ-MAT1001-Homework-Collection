# MAT1001 L07 Homework Collection

本项目包含 48 个小节、565 个指定题号，共 82 页；不含答案。

本次修订保留双栏；题目正文、公式与插图统一放大约 8%，主要正文约 9.7 磅。
封面后第 2 页预留为 Document Notes（文档说明），第 3 页为可点击目录。
重新按教材字符的实际显示边界提取，补齐区间括号、极限趋近式、上下标、
共用题干的完整步骤与必要共享示意图。

范围以 MAT1001 L07 Course Details 2026 的 Homework Assignments 为准。
4.2 第 15 题按已确认的 a(iii) 和 b 收录。
另提供 2.5 第 63 题与 8.8 第 75 题的必要引用背景。

## 编译

常规：使用 XeLaTeX 编译 main.tex。
离线：安装 Tectonic 后，在项目目录运行：
tectonic -X compile offline.tex --bundle local.zip --format mini

## 文件

- main.tex：常规 LaTeX 入口。
- pages.tex、layout.tex：文字、数学字形及公式组件的坐标式矢量排版源稿。
- fonts/：排版使用的 SF Pro 字形及数学字形。
- images/backgrounds.pdf：必要原图与公式线条；原图标签保留原样。
- assignment-index.json：课程选题索引。

排版源稿采用字形与坐标方式重建公式，并非逐式语义化的数学表达式。
正文使用 SF Pro Text，标题使用 SF Pro Display；原图保留教材的图内字体。
